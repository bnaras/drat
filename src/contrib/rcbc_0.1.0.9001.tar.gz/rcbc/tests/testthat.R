library(testthat)
library(rcbc)

test_check("rcbc")
