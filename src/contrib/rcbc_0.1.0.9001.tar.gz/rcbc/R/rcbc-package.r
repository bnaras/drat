#' CBC bindigns for R
#'
#' @docType package
#' @keywords package
#' @useDynLib rcbc
#' @importFrom Rcpp sourceCpp
#' @name rcbc
NULL
