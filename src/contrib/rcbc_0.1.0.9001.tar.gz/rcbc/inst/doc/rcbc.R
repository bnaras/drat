## -----------------------------------------------------------------------------
# load rcbc package
library(rcbc)

# create vector to describe the objective function (eqn 1a)
## each element corresponds to a decision variable,
## and the values are the coefficients
obj <- c("x" = 1, "y" = 2, "z" = 0.5)

## print object
print(obj)

# create vector to indicate which variables are integer (eqns 1e -- 1g)
## TRUE means that the variable is an integer
## FALSE means that the variable is not an integer (i.e. continuous)
is_int <- c("x" = TRUE, "y" = TRUE, "z" = TRUE)

## print object
print(is_int)

# create vector to indicate the maximum value for each variable (eqns 1e -- 1g)
## create object
col_ub <- c("x" = 10, "y" = 11, "z" = 13)

## print object
print(col_ub)

# create vector to indicate the minimum value for each variable (eqns 1e -- 1g)
## create object
col_lb <- c("x" = 0, "y" = 0, "z" = 0)

## print object
print(col_lb)

# create matrix to describe the constraint coefficients (eqns 1b -- 1d)
## this matrix will describe the inequality and equality constraints,
## and for these constraints it will contain the coefficients that
## are on the left hand side of the ">=", "<=", and "=" symbols
A <- matrix(c(1, 1, 0, 3, 0, 4, 1, 0, 1), byrow = TRUE, ncol = 3)
rownames(A) <- c("(eqn 1b)", "(eqn 1c)", "(eqn 1d)")
colnames(A) <- c("x", "y", "z")

## print object
print(A)

# create vector to describe the constraint upper limits (eqns 1b -- 1d)
## specifically, these describe the maximum possible value when
## applying the equations on the left hand side of the ">=", "<=", and "="
## symbols. note that eqn 1c has a maximum possible value of Inf
## because it has a >= inequality
row_ub <- c("(eqn 1b)" = 1, "(eqn 1c)" = Inf, "(eqn 1d)" = 8)

## print object
print(row_ub)

# create vector to describe the constraint lower limits (eqns 1b -- 1d)
## specifically, these describe the minimum possible value when
## applying the equations on the left hand side of the ">=", "<=", and "="
## symbols. note that eqn 1b has a minimum possible value of -Inf
## because it has a <= inequality
row_lb <- c("(eqn 1b)" = -Inf, "(eqn 1c)" = 5, "(eqn 1d)" = 8)

## print object
print(row_lb)

## -----------------------------------------------------------------------------
# solve problem to optimality
## note that we specify `max = TRUE` because our problem is to maximize
## the objective value (per eqn 1a)
result <- cbc_solve(
  obj = obj, mat = A,
  col_ub = col_ub, col_lb = col_lb,
  row_ub = row_ub, row_lb = row_lb,
  is_integer = is_int, max = TRUE)

## -----------------------------------------------------------------------------
# solution values
## extract values
sol <- column_solution(result)

## set variable names
names(sol) <- c("x", "y", "z")

## print object
print(sol)

# extract objective value
## extract value
objv <- objective_value(result)

## print object
print(objv)

# status
## extract information
status <- solution_status(result)

## print value
print(status)

## -----------------------------------------------------------------------------
# create dir object following Rsymphony_solve_LP format (per eqn 1)
## create object
dir <- c("(eqn 1b)" = "<=", "(eqn 1c)" = ">=", "(eqn 1d)" = "=")

## print object
print(dir)

# create rhs object following Rsymphony_solve_LP format (per eqn 1)
## create object
rhs <- c("(eqn 1b)" = 1, "(eqn 1c)" = 5, "(eqn 1d)" = 8)

## print object
print(rhs)

## -----------------------------------------------------------------------------
# initialize objects for rcbc
row_ub2 <- numeric(length(dir))
row_lb2 <- numeric(length(dir))

# convert >= constraints
idx <- dir == ">="
row_lb2[idx] <- rhs[idx]
row_ub2[idx] <- Inf

# convert <= constraints
idx <- dir == "<="
row_lb2[idx] <- -Inf
row_ub2[idx] <- rhs[idx]

# convert = constraints
idx <- dir == "="
row_lb2[idx] <- rhs[idx]
row_ub2[idx] <- rhs[idx]

## -----------------------------------------------------------------------------
# print constraint upper bound objects (note that names are unnecessary)
## print row_ub object we created earlier
print(row_ub)

## print row_ub2 object converted from rhs and dir objects
print(row_ub2)

# print constraint lower bound objects (note that names are unnecessary)
## print row_lb object we created earlier
print(row_lb)

## print row_lb2 object converted from rhs and dir objects
print(row_lb2)

## ---- include = FALSE---------------------------------------------------------
# verify that objects actually are the same
assertthat::assert_that(
  identical(unname(row_ub), row_ub2),
  identical(unname(row_lb), row_lb2))

## ---- echo  = FALSE, result = "asis", comment = ""----------------------------
citation("rcbc")

