## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = requireNamespace("ipopt", quietly = TRUE)
)
library(ipopt)

## ----quiet--------------------------------------------------------------------
quiet <- list(print_level = 0L, sb = "yes")

## ----hs071--------------------------------------------------------------------
hs071 <- ipopt_solve(
  x0    = c(1, 5, 5, 1),
  lower = rep(1, 4),
  upper = rep(5, 4),
  constraint_lower = c(25, 40),     # g1 >= 25  (upper Inf); g2 == 40
  constraint_upper = c(Inf, 40),

  eval_f = function(x) x[1] * x[4] * (x[1] + x[2] + x[3]) + x[3],

  eval_grad_f = function(x) c(
    x[4] * (2 * x[1] + x[2] + x[3]),
    x[1] * x[4],
    x[1] * x[4] + 1,
    x[1] * (x[1] + x[2] + x[3])
  ),

  eval_g = function(x) c(prod(x), sum(x^2)),

  # dense 2 x 4 Jacobian: rows (1,1,1,1, 2,2,2,2), cols (1,2,3,4, 1,2,3,4)
  jacobian_structure = cbind(rep(1:2, each = 4), rep(1:4, 2)),
  eval_jac_g = function(x) c(
    x[2] * x[3] * x[4], x[1] * x[3] * x[4],          # d g1 / d x1, x2
    x[1] * x[2] * x[4], x[1] * x[2] * x[3],          # d g1 / d x3, x4
    2 * x[1], 2 * x[2], 2 * x[3], 2 * x[4]           # d g2 / d x
  ),

  # lower triangle of the 4 x 4 Lagrangian Hessian (row >= col), row by row
  hessian_structure = cbind(
    c(1, 2, 2, 3, 3, 3, 4, 4, 4, 4),
    c(1, 1, 2, 1, 2, 3, 1, 2, 3, 4)
  ),
  eval_h = function(x, obj_factor, lambda) {
    of <- obj_factor; l1 <- lambda[1]; l2 <- lambda[2]
    c(
      of * (2 * x[4])                  + l2 * 2,        # (1,1)
      of * x[4]            + l1 * (x[3] * x[4]),        # (2,1)
      0                                + l2 * 2,        # (2,2)
      of * x[4]            + l1 * (x[2] * x[4]),        # (3,1)
                             l1 * (x[1] * x[4]),        # (3,2)
      0                                + l2 * 2,        # (3,3)
      of * (2 * x[1] + x[2] + x[3]) + l1 * (x[2] * x[3]),  # (4,1)
      of * x[1]            + l1 * (x[1] * x[3]),        # (4,2)
      of * x[1]            + l1 * (x[1] * x[2]),        # (4,3)
      0                                + l2 * 2         # (4,4)
    )
  },

  options = c(quiet, tol = 1e-8)
)

hs071$status_code
hs071$solution
hs071$objective
hs071$constraints                 # should hit 25 and 40

## ----rosenbrock---------------------------------------------------------------
rosen <- ipopt_solve(
  x0    = c(-1.2, 1),               # the traditional hard starting point
  lower = c(-Inf, -Inf),
  upper = c(Inf, Inf),

  eval_f = function(x) (1 - x[1])^2 + 100 * (x[2] - x[1]^2)^2,

  eval_grad_f = function(x) c(
    -2 * (1 - x[1]) - 400 * x[1] * (x[2] - x[1]^2),
    200 * (x[2] - x[1]^2)
  ),

  hessian_structure = cbind(c(1, 2, 2), c(1, 1, 2)),
  eval_h = function(x, obj_factor, lambda) obj_factor * c(
    2 - 400 * x[2] + 1200 * x[1]^2,   # (1,1)
    -400 * x[1],                      # (2,1)
    200                               # (2,2)
  ),

  options = c(quiet, tol = 1e-10)
)

rosen$status_code
rosen$solution
rosen$objective

## ----rosenbrock-lbfgs---------------------------------------------------------
rosen_lm <- ipopt_solve(
  x0    = c(-1.2, 1),
  lower = c(-Inf, -Inf),
  upper = c(Inf, Inf),

  eval_f = function(x) (1 - x[1])^2 + 100 * (x[2] - x[1]^2)^2,
  eval_grad_f = function(x) c(
    -2 * (1 - x[1]) - 400 * x[1] * (x[2] - x[1]^2),
    200 * (x[2] - x[1]^2)
  ),

  eval_h = NULL,
  options = c(quiet, tol = 1e-8, hessian_approximation = "limited-memory")
)

rosen_lm$status_code
rosen_lm$solution

## ----maxent-------------------------------------------------------------------
K       <- 5
support <- 1:K
mu      <- 2                       # desired mean (uniform mean would be 3)

ent <- ipopt_solve(
  x0    = rep(1 / K, K),            # start at the uniform distribution
  lower = rep(1e-8, K),            # keep p_i > 0 so log p_i is finite
  upper = rep(1, K),
  constraint_lower = c(1, mu),     # both equalities: lower == upper
  constraint_upper = c(1, mu),

  eval_f      = function(p) sum(p * log(p)),
  eval_grad_f = function(p) log(p) + 1,

  eval_g = function(p) c(sum(p), sum(support * p)),
  jacobian_structure = cbind(rep(1:2, each = K), rep(1:K, 2)),
  eval_jac_g = function(p) c(rep(1, K), support),

  hessian_structure = cbind(1:K, 1:K),               # diagonal only
  eval_h = function(p, obj_factor, lambda) obj_factor * (1 / p),

  options = c(quiet, tol = 1e-9)
)

ent$status_code
round(ent$solution, 5)
c(total = sum(ent$solution), mean = sum(support * ent$solution))

## ----maxent-check-------------------------------------------------------------
theta <- ent$constraint_multipliers[2]
closed_form <- exp(-theta * support)
closed_form <- closed_form / sum(closed_form)
round(closed_form, 5)              # matches ent$solution

