## Gurobi installation

This package requires an installation of the gurobi optimizer first
from the [Gurobi site](https://www.gurobi.com)


## For Linux

Define environment variable `GUROBI_HOME` first, e.g. `export
GUROBI_HOME=/opt/gurobi903/linux64`. 

```
make -f inst/Makefiles/Makefile.linux
```

## For Mac

```
make -f inst/Makefiles/Makefile.mac
```

## For Windows

Build Gurobi R package for win64, using cygwin shell. Define
`GUROBI_HOME` first, e.g. `GUROBI_HOME=C:/gurobi903/win64`. Then 

```
make -f inst/Makefiles/Makefile.win
```

